function q = quadgk(fun,a,b)
q = quadl(fun,a,b);
return;